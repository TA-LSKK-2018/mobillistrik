module.exports = {
    database: 'mongodb://localhost:27017/EVOI', // You should change this according to your environments
	//mongodb://username:pass@ip:27017/dbname
    secret: 'yoursecret-123'
}