
var userRoles = role.UserRole = {
    guest : 1,
    user: 2,
    admin: 4,
    superadmin: 5
}

